CREATE TABLE NganHang (
    MaNH NUMBER PRIMARY KEY,
    TenNH NVARCHAR2(100)
);

CREATE TABLE ChiNhanh (
    MaCN VARCHAR2(10) PRIMARY KEY,
    MaNH NUMBER,
    ThanhPhoCN NVARCHAR2(100),
    TaiSan NUMBER,
    CONSTRAINT fk_cn_nh FOREIGN KEY (MaNH) REFERENCES NganHang(MaNH)
);

CREATE TABLE KhachHang (
    MaKH VARCHAR2(20) PRIMARY KEY,
    TenKH NVARCHAR2(100),
    DiaChi NVARCHAR2(200)
);

CREATE TABLE TaiKhoanGoi (
    MaKH VARCHAR2(20),
    MaCN VARCHAR2(10),
    SoTKG VARCHAR2(20),
    SoTienGoi NUMBER,
    PRIMARY KEY (SoTKG),
    CONSTRAINT fk_tkg_kh FOREIGN KEY (MaKH) REFERENCES KhachHang(MaKH),
    CONSTRAINT fk_tkg_cn FOREIGN KEY (MaCN) REFERENCES ChiNhanh(MaCN)
);

CREATE TABLE TaiKhoanVay (
    MaKH VARCHAR2(20),
    MaCN VARCHAR2(10),
    SoTKV VARCHAR2(20),
    SoTienVay NUMBER,
    PRIMARY KEY (SoTKV),
    CONSTRAINT fk_tkv_kh FOREIGN KEY (MaKH) REFERENCES KhachHang(MaKH),
    CONSTRAINT fk_tkv_cn FOREIGN KEY (MaCN) REFERENCES ChiNhanh(MaCN)
);
-------------------------------------------------------------------
INSERT INTO NganHang VALUES (1, N'Ngan Hang Cong Thuong');
INSERT INTO NganHang VALUES (2, N'Ngan Hang Ngoai Thuong');
INSERT INTO NganHang VALUES (3, N'Ngan Hang Nong Nghiep');
INSERT INTO NganHang VALUES (4, N'Ngan Hang A Chau');
INSERT INTO NganHang VALUES (5, N'Ngan Hang Thuong Tin');
----------------------------------------------------------------------
INSERT INTO ChiNhanh VALUES ('CN01',1,N'Da Lat',2000000000);
INSERT INTO ChiNhanh VALUES ('CN02',2,N'Nha Trang',2700000000);
INSERT INTO ChiNhanh VALUES ('CN03',3,N'Thanh Hoa',4500000000);
INSERT INTO ChiNhanh VALUES ('CN04',4,N'TP HCM',6000000000);
INSERT INTO ChiNhanh VALUES ('CN05',5,N'Da Nang',7000000000);
INSERT INTO ChiNhanh VALUES ('CN11',1,N'TP HCM',5000000000);
INSERT INTO ChiNhanh VALUES ('CN12',2,N'Hue',1400000000);
INSERT INTO ChiNhanh VALUES ('CN13',3,N'Da Nang',3600000000);
INSERT INTO ChiNhanh VALUES ('CN14',4,N'Ha Noi',5700000000);
INSERT INTO ChiNhanh VALUES ('CN21',1,N'Ha Noi',3500000000);
INSERT INTO ChiNhanh VALUES ('CN22',2,N'Ha Noi',4500000000);
INSERT INTO ChiNhanh VALUES ('CN23',3,N'Da Lat',2400000000);
INSERT INTO ChiNhanh VALUES ('CN31',1,N'Da Nang',4000000000);
INSERT INTO ChiNhanh VALUES ('CN32',2,N'TP HCM',5600000000);
INSERT INTO ChiNhanh VALUES ('CN33',3,N'Can Tho',5400000000);
INSERT INTO ChiNhanh VALUES ('CN43',3,N'Nam Dinh',3600000000);
-----------------------------------------------------------------------
INSERT INTO KhachHang VALUES ('111222333', N'Ho Thi Thanh Thao', N'456 Le Duan, Ha Noi');
INSERT INTO KhachHang VALUES ('112233445', N'Tran Van Tien', N'12 Dien Bien Phu, Q1, TP HCM');
INSERT INTO KhachHang VALUES ('123123123', N'Phan Thi Quynh Nhu', N'54 Hai Ba Trung, Ha Noi');
INSERT INTO KhachHang VALUES ('123412341', N'Nguyen Van Thao', N'34 Tran Phu, TP Nha Trang');
INSERT INTO KhachHang VALUES ('123456789', N'Nguyen Thi Hoa', N'1/4 Hoang Van Thu, Da Lat');
INSERT INTO KhachHang VALUES ('221133445', N'Nguyen Thi Kim Mai', N'4 Tran Binh Trong, Da Lat');
INSERT INTO KhachHang VALUES ('222111333', N'Do Tien Dong', N'123 Tran Phu, Nam Dinh');
INSERT INTO KhachHang VALUES ('331122445', N'Bui Thi Dong', N'345 Tran Hung Dao, Thanh Hoa');
INSERT INTO KhachHang VALUES ('333111222', N'Tran Dinh Hung', N'783 Ly Thuong Kiet, Can Tho');
INSERT INTO KhachHang VALUES ('441122335', N'Nguyen Dinh Cuong', N'P12 Thanh Xuan Nam, Q Thanh Xuan');
INSERT INTO KhachHang VALUES ('456456456', N'Tran Nam Son', N'5 Le Duan, TP Da Nang');
INSERT INTO KhachHang VALUES ('551122334', N'Tran Thi Khanh Van', N'1A Ho Tung Mau, Da Lat');
INSERT INTO KhachHang VALUES ('987654321', N'Ho Thanh Son', N'209 Tran Hung Dao, Q5, TP HCM');
-----------------------------------------------------------------------
INSERT INTO TaiKhoanGoi VALUES ('123123123','CN01','00001A',10000000);
INSERT INTO TaiKhoanGoi VALUES ('123456789','CN01','00001C',127000000);
INSERT INTO TaiKhoanGoi VALUES ('221133445','CN02','00002A',12500000);
INSERT INTO TaiKhoanGoi VALUES ('456456456','CN03','00003H',123000000);
INSERT INTO TaiKhoanGoi VALUES ('222111333','CN05','00005A',1200000);
INSERT INTO TaiKhoanGoi VALUES ('987654321','CN05','00005D',345000000);
INSERT INTO TaiKhoanGoi VALUES ('123412341','CN05','00005N',45000000);
INSERT INTO TaiKhoanGoi VALUES ('331122445','CN13','00003A',27000000);
INSERT INTO TaiKhoanGoi VALUES ('551122334','CN14','00004D',560000000);
INSERT INTO TaiKhoanGoi VALUES ('123456789','CN14','00004P',35400000);
INSERT INTO TaiKhoanGoi VALUES ('123412341','CN21','00001B',67000000);
INSERT INTO TaiKhoanGoi VALUES ('222111333','CN22','00002G',56000000);
INSERT INTO TaiKhoanGoi VALUES ('987654321','CN23','00004F',4500000);
INSERT INTO TaiKhoanGoi VALUES ('333111222','CN33','00003D',47000000);
-----------------------------------------------------------------------
INSERT INTO TaiKhoanVay VALUES ('111222333','CN01','10001A',10000000);
INSERT INTO TaiKhoanVay VALUES ('333111222','CN02','10002A',6000000);
INSERT INTO TaiKhoanVay VALUES ('551122334','CN04','10004A',20000000);
INSERT INTO TaiKhoanVay VALUES ('221133445','CN05','10005G',15000000);
INSERT INTO TaiKhoanVay VALUES ('987654321','CN11','10001D',45000000);
INSERT INTO TaiKhoanVay VALUES ('112233445','CN12','10002D',12000000);
INSERT INTO TaiKhoanVay VALUES ('441122335','CN13','10003F',5500000);
INSERT INTO TaiKhoanVay VALUES ('123123123','CN14','10005A',12500000);
COMMIT;
---------------------------------------------------------------------------
-- 1 Tìm tên tất cả các ngân hàng có chi nhánh ngân hàng ở thanh phố “Da Lat”.
SELECT DISTINCT NH.TenNH
FROM NganHang NH JOIN ChiNhanh CN ON NH.MaNH = CN.MaNH
WHERE CN.ThanhPhoCN = N'Da Lat';

-- 2 Tìm tất cả những thành phố mà có chi nhánh của ngân hàng công thương.
SELECT DISTINCT CN.ThanhPhoCN
FROM NganHang NH JOIN ChiNhanh CN ON NH.MaNH = CN.MaNH
WHERE NH.TenNH = N'Ngan Hang Cong Thuong';

-- 3 Tìm thông tin về tất cả các chi nhánh của ngân hàng công thương có địa điểm ở TPHCM.
SELECT CN.*
FROM NganHang NH JOIN ChiNhanh CN ON NH.MaNH = CN.MaNH
WHERE NH.TenNH = N'Ngan Hang Cong Thuong' AND CN.ThanhPhoCN = N'TP HCM';

-- 4 Xuất thông tin từng ngân hàng và chi nhánh của nó.
SELECT NH.TenNH, CN.MaCN, CN.ThanhPhoCN, CN.TaiSan
FROM NganHang NH JOIN ChiNhanh CN ON NH.MaNH = CN.MaNH;

-- 5 Tìm khách hàng mà địa chỉ của họ ở 'Ha Noi'.
SELECT * FROM KhachHang WHERE DiaChi LIKE N'%Ha Noi%';

-- 6 Tìm các khách hàng có tên Son.
SELECT * FROM KhachHang WHERE TenKH LIKE N'%Son%';

-- 7 Tìm các khách hàng mà địa chỉ của họ ở đường "Tran Hung Dao".
SELECT * FROM KhachHang WHERE DiaChi LIKE N'%Tran Hung Dao%';

-- 8
SELECT * FROM KhachHang WHERE TenKH LIKE N'%Thao%';

-- 9
SELECT * FROM KhachHang WHERE MaKH LIKE '11%' AND DiaChi LIKE N'%TP HCM%';

-- 10
SELECT NH.TenNH, CN.ThanhPhoCN, CN.TaiSan
FROM NganHang NH JOIN ChiNhanh CN ON NH.MaNH = CN.MaNH
ORDER BY CN.TaiSan ASC, CN.ThanhPhoCN ASC;

-- 11
SELECT NH.*, CN.*
FROM NganHang NH JOIN ChiNhanh CN ON NH.MaNH = CN.MaNH
WHERE CN.TaiSan BETWEEN 3000000000 AND 5000000000;

-- 12
SELECT NH.TenNH, AVG(CN.TaiSan) AS TaiSanTB
FROM NganHang NH JOIN ChiNhanh CN ON NH.MaNH = CN.MaNH
GROUP BY NH.TenNH;

-- 13
SELECT DISTINCT KH.*
FROM KhachHang KH
JOIN TaiKhoanVay V ON KH.MaKH = V.MaKH
JOIN ChiNhanh CN ON V.MaCN = CN.MaCN
JOIN NganHang NH ON CN.MaNH = NH.MaNH
WHERE NH.TenNH = N'Ngan Hang Cong Thuong' AND KH.TenKH LIKE N'%Thao%';

-- 14
SELECT NH.TenNH, SUM(CN.TaiSan) AS TongTaiSan
FROM NganHang NH JOIN ChiNhanh CN ON NH.MaNH = CN.MaNH
GROUP BY NH.TenNH;

-- 15
SELECT MaCN, TaiSan
FROM ChiNhanh
WHERE TaiSan = (SELECT MAX(TaiSan) FROM ChiNhanh);

-- 16
SELECT DISTINCT KH.*
FROM KhachHang KH
JOIN TaiKhoanGoi G ON KH.MaKH = G.MaKH
JOIN ChiNhanh CN ON G.MaCN = CN.MaCN
JOIN NganHang NH ON CN.MaNH = NH.MaNH
WHERE NH.TenNH = N'Ngan Hang A Chau';

-- 17
SELECT V.SoTKV
FROM TaiKhoanVay V
JOIN ChiNhanh CN ON V.MaCN = CN.MaCN
JOIN NganHang NH ON CN.MaNH = NH.MaNH
WHERE NH.TenNH = N'Ngan Hang Ngoai Thuong' AND V.SoTienVay > 1200000;

-- 18
SELECT CN.MaCN, SUM(G.SoTienGoi) AS TongTienGoi
FROM ChiNhanh CN JOIN TaiKhoanGoi G ON CN.MaCN = G.MaCN
GROUP BY CN.MaCN;

-- 19
SELECT KH.TenKH, V.SoTKV, G.SoTKG
FROM KhachHang KH
LEFT JOIN TaiKhoanVay V ON KH.MaKH = V.MaKH
LEFT JOIN TaiKhoanGoi G ON KH.MaKH = G.MaKH
WHERE KH.TenKH LIKE N'%Son%';

-- 20
SELECT KH.*
FROM KhachHang KH
JOIN TaiKhoanVay V ON KH.MaKH = V.MaKH
GROUP BY KH.MaKH, KH.TenKH, KH.DiaChi
HAVING SUM(V.SoTienVay) > 30000000;

